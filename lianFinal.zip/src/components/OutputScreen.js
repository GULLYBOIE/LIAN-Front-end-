import React from 'react';

const styles = {
    container: {
        width: '25em',
        height: '20em',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '2em'
    },
    box: {
        border: '2px dotted #000000',
        width: '31em',
        height: '25em'
    },
    boxe: {
        border: '2px dotted #000000',
        width: '25em',
        height: '20em',
        borderRadius: '5em',
        padding: '0em 3em'

    },
    btnContainer: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      },
      btn: {
        fontSize: "1.2em",
        padding: "0.5em",
        margin: "0.5em",
        borderRadius: "0.5em",
        border: "none",
        backgroundColor: "#002CFE",
        color: "#f4f4f4",
        cursor: "pointer",
      },
}

const OutputScreen = () => {
    return (
        <div style={styles.container}>
            <h2>OUTPUT</h2>
            <div style = {styles.box}>
            <div style = {styles.boxe}></div>
            </div>
            <div style = {styles.btnContainer}>
                <button style = {styles.btn}>Acceptable</button>
                <button style={styles.btn}>Clear</button>
                <button style = {styles.btn}>Unacceptable</button>
            </div>
        </div>
    );
}

export default OutputScreen;
