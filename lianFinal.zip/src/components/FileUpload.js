import React, {useEffect} from 'react'
import { useState } from "react";
import { FileUploader } from "react-drag-drop-files"

const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    
    
  },
  dropMessageStyle: {
    height: "25em",
    width: "20em",
  },

  image: {
    width: '300px',
    height: '150px',
  },
}

const fileTypes = ["JPEG", "PNG", "GIF"];


const FileUpload = ({clicked}) => {
  useEffect(() => handleChange(null), [clicked])
  const [file, setFile] = useState(null);
  const handleChange = (file) => setFile(file)
  
  return (
    <div style={styles.container}>
      <FileUploader
        multiple={true}
        handleChange={handleChange}
        name="file"
        types={fileTypes}
        fileOrFiles={file}
        dropMessageStyle={styles.dropMessageStyle}
      />
      {file ? (
        <div>
          <img src={URL.createObjectURL(file[0])} style={styles.image} alt="Selected file" />
          <p>File name: {file[0].name}</p>
        </div>
      ) : (
        <p>No files uploaded yet</p>
      )}
    </div>
  )
}


export default FileUpload