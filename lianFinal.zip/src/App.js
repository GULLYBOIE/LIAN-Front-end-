import React, { useState } from 'react'
import FileUpload from './components/FileUpload'
import './App.css'
import OutputScreen from './components/OutputScreen'
import i from './components/logo.png';

const styles = {
  mainContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-evenly",
  },
  container: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 100,
  },
  app: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  heading: {
    fontSize: "4em",
  },
  btnContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  btn: {
    fontSize: "1.2em",
    padding: "0.5em",
    margin: "0.5em",
    borderRadius: "0.5em",
    border: "none",
    backgroundColor: "#002CFE",
    color: "#f4f4f4",
    cursor: "pointer",
    
  },
 b: {
    fontSize: "2em",
    padding: "0.5em",
    margin: "0.5em",
    borderRadius: "0.2em",
    border: "none",
    backgroundColor: "#002CFE",
    color: "#f4f4f4",
    cursor: "pointer",
   

 },
 bt: {
  fontSize: "1.5em",
  padding: "0.5em",
  margin: "0.5em",
  borderRadius: "0.2em",
  border: "none",
  backgroundColor: "#002CFE",
  color: "#f4f4f4",
  cursor: "pointer",
  width: "5em",
 

},
 header: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 500,
    

 },
 footer: {
    display: "flex",
    flexDirection: "row",
    

 },
 box: {
    border: '2px solid #000000',
    width: '10em',
    height: '8em'

 },

  
  
}

const App = () => {
    const [clicked, setClicked] = useState(false)
    const handleClick = () => setClicked(!clicked)
    return (
      <div>
        <div style={styles.header}>
        <img src={i} classname='logo' alt='logo' style={styles.img}/>
        <h1 style={styles.heading}>LIAN</h1>
        </div>
      <div style={styles.mainContainer}>
       
        
        <div style = {styles.container}>
          <div style={styles.app}>
            <FileUpload clicked = {clicked}/>
            <div style={styles.btnContainer}>
              <button
                style={styles.btn}
                onClick = {() => handleClick()}
              >Clear Image</button>
              <button style={styles.btn}>Process Image</button>
            </div>
          </div>
          <div>
            <OutputScreen/>
          </div>
        </div>
      </div>
      <div style={styles.footer}>
      <button style={styles.bt}>Recent Images</button>
      <div style={styles.box}></div>
      <div style={styles.box}></div>
      <div style={styles.box}></div>
      
      </div>
      </div>
  )
}

export default App